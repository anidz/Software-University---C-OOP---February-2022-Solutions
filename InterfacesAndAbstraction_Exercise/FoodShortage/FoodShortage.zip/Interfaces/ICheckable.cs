﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface ICheckable
    {
        string Id { get; }
    }
}

