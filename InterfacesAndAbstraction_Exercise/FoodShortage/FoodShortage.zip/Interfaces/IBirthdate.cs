﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
