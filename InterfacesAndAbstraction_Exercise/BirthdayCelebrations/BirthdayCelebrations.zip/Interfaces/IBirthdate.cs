﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Interfaces
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
