﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Interfaces
{
    public interface IUsed
    {
        public int Used { get; }
    }
}
