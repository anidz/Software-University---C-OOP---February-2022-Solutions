﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ValidationAttributes.Core
{
    public interface IEngine
    {
        void Proceed();
    }
}
