﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Interfaces.Animals
{
    public interface IFeline
    {
        public string Breed { get; }
    }
}
