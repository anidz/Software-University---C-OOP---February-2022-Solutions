﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Interfaces.Animals
{
    public interface IProduceSound
    {
        string ProduceSound();
    }
}
