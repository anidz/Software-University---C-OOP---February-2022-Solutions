﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
