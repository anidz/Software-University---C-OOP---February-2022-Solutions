﻿using Raiding.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.IO
{
    public class Reader : IReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
