﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
